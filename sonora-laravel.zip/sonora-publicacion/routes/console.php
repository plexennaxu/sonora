<?php

// Rutas de consola de la aplicación.
