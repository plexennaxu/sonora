<?php

use Illuminate\Support\Facades\Route;

$catalog = static fn () => [
    'tracks' => config('sonora.tracks'),
    'playlists' => config('sonora.playlists'),
];

Route::get('/', fn () => view('inicio', $catalog()))->name('home');

Route::get('/playlist/{id}', function (string $id) use ($catalog) {
    $data = $catalog();
    $playlist = collect($data['playlists'])->firstWhere('id', $id);
    abort_unless($playlist, 404);
    $tracksById = collect($data['tracks'])->keyBy('id');
    $playlistTracks = collect($playlist['tracks'])->map(fn ($trackId) => $tracksById->get($trackId))->filter()->values()->all();

    return view('playlist', $data + compact('playlist', 'playlistTracks'));
})->name('playlists.show');

Route::get('/reproductor', fn () => view('reproductor', $catalog()))->name('player');
