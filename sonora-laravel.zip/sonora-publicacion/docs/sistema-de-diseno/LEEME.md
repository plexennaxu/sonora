# Sonora: paquete del sistema de diseño

- `docs/Proyecto-alumnos.md`: brief y rúbrica del proyecto. Empieza aquí.
- `docs/Sistema.md`: reglas de uso (contenido, color, tipografía, formas, iconos).
- `docs/Tailwind-y-Laravel.md`: tokens en Tailwind, recetas de clases, reproductor simulado y paso a Laravel.
- `css/app.css`: tokens listos para pegar en `resources/css/app.css` (Tailwind v4).
- `css/tokens.css` y `css/componentes.css`: variables y clases `snr-` para quien no use Tailwind.
- `tokens.json`: todos los tokens con su nota de uso.
- `logos/`: marca ámbar (tema oscuro) y `#a65500` (tema claro).
- `iconos/`: 10 iconos con `currentColor`; incrústalos en el HTML (`<svg>`) para que tomen el color del texto.
- `iconos-tinta-oscura/`: los mismos iconos con color fijo `#f4f2ee`, para usar con `<img>` solo en tema oscuro.

Las tipografías (Manrope y JetBrains Mono) se cargan desde Google Fonts.
