@props(['class' => 'h-8 w-8'])
<span {{ $attributes->class(['inline-flex shrink-0 text-accent [&_svg]:h-full [&_svg]:w-full', $class]) }} aria-hidden="true">{!! str_replace('#ffb020', 'currentColor', file_get_contents(public_path('assets/logos/sonora-mark-dark.svg'))) !!}</span>
