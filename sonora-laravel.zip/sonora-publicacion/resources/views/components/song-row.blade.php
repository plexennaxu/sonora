@props(['track', 'number' => null])
@php($duration = (int) data_get($track, 'duration', 0))
<div class="group grid grid-cols-[2rem_minmax(0,1fr)_auto_auto] items-center gap-3 rounded-md px-2 py-3 transition-colors hover:bg-surface-high">
    <span class="text-center font-mono text-xs text-ink-muted">{{ $number ? str_pad($number, 2, '0', STR_PAD_LEFT) : '•' }}</span>
    <div class="min-w-0"><p class="truncate text-sm font-bold text-ink">{{ data_get($track, 'title') }}</p><p class="truncate text-sm text-ink-muted">{{ data_get($track, 'artist') }}</p></div>
    <span class="font-mono text-xs text-ink-muted">{{ sprintf('%02d:%02d', intdiv($duration, 60), $duration % 60) }}</span>
    <button type="button" data-play-track="{{ data_get($track, 'id') }}" class="inline-flex h-10 w-10 items-center justify-center rounded-pill text-ink hover:bg-surface-base" aria-label="Reproducir {{ data_get($track, 'title') }}"><x-icon name="play" /></button>
</div>
