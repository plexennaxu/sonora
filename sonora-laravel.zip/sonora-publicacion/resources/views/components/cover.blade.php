@props(['playlist' => 'mezcla-diaria'])
@php
    $patterns = [
        'mezcla-diaria' => [24, 42, 34, 54, 22],
        'horas-lentas' => [50, 28, 40, 18, 47],
        'camino-abierto' => [30, 54, 36, 45, 32],
        'luz-de-noche' => [20, 38, 56, 30, 42],
    ];
    $bars = $patterns[$playlist] ?? $patterns['mezcla-diaria'];
@endphp
<svg viewBox="0 0 64 64" width="72%" height="72%" style="color:var(--accent)" aria-hidden="true" xmlns="http://www.w3.org/2000/svg">
    @foreach($bars as $height)
        <rect x="{{ 4 + $loop->index * 12 }}" y="{{ 60 - $height }}" width="9" height="{{ $height }}" rx="4.5" fill="currentColor" />
    @endforeach
</svg>
