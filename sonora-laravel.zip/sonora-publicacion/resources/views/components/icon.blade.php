@props(['name', 'class' => 'h-5 w-5'])
<span {{ $attributes->class(['inline-flex shrink-0 items-center justify-center [&_svg]:h-full [&_svg]:w-full', $class]) }} aria-hidden="true">{!! file_get_contents(public_path('assets/icons/'.$name.'.svg')) !!}</span>
