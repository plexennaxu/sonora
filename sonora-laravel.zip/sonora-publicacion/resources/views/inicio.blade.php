@extends('layouts.app')
@section('title', 'Inicio')
@section('content')
<section class="grid items-center gap-8 rounded-lg bg-surface-raised p-6 sm:p-8 lg:grid-cols-[1fr_17rem]" aria-labelledby="bienvenida">
    <div><p class="mb-3 text-xs font-bold uppercase tracking-wider text-ink-muted">Bienvenido a Sonora</p><h1 id="bienvenida" class="max-w-2xl text-4xl font-extrabold leading-tight tracking-tight sm:text-5xl">Tu música, sin ruido</h1><p class="mt-4 max-w-xl text-base leading-6 text-ink-muted">Encuentra el ritmo para cada momento. Tus canciones y playlists, en un solo lugar.</p><button type="button" data-play-track="{{ data_get(collect($tracks)->first(), 'id') }}" class="mt-6 inline-flex items-center gap-2 rounded-pill bg-accent px-6 py-3 text-sm font-bold text-on-accent hover:bg-accent-hover"><x-icon name="play" /> Escuchar ahora</button></div>
    <div class="hidden aspect-square items-center justify-center rounded-md bg-surface-high text-ink-muted lg:flex" aria-hidden="true"><x-logo class="h-24 w-24" /></div>
</section>
<section id="playlists" class="mt-8" aria-labelledby="playlists-title"><div class="mb-4 flex items-end justify-between gap-4"><div><p class="mb-1 text-xs font-bold uppercase tracking-wider text-ink-muted">Para cada momento</p><h2 id="playlists-title" class="text-2xl font-extrabold tracking-tight">Tus playlists</h2></div><span class="font-mono text-xs text-ink-muted">{{ count($playlists) }} playlists</span></div><div class="grid grid-cols-2 gap-4 lg:grid-cols-4">@foreach($playlists as $item)<x-media-card :playlist="$item" />@endforeach</div></section>
<section class="mt-8" aria-labelledby="songs-title"><div class="mb-4"><p class="mb-1 text-xs font-bold uppercase tracking-wider text-ink-muted">Tu selección</p><h2 id="songs-title" class="text-2xl font-extrabold tracking-tight">Canciones para ti</h2></div><div class="rounded-lg bg-surface-raised p-4">@foreach($tracks as $track)<x-song-row :track="$track" :number="$loop->iteration" />@endforeach</div></section>
@endsection

