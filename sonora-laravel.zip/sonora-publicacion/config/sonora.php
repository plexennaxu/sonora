<?php

// Catálogo ficticio para la demostración. Las duraciones están en segundos.
return [
    'tracks' => [
        ['id' => 1, 'title' => 'La ciudad se apaga', 'artist' => 'Estación Bruma', 'duration' => 224],
        ['id' => 2, 'title' => 'Luz sobre el agua', 'artist' => 'Mapa de Sal', 'duration' => 198],
        ['id' => 3, 'title' => 'Aire de regreso', 'artist' => 'Los Días Lentos', 'duration' => 246],
        ['id' => 4, 'title' => 'Después de llover', 'artist' => 'Estación Bruma', 'duration' => 213],
        ['id' => 5, 'title' => 'Pequeñas órbitas', 'artist' => 'Nube de Papel', 'duration' => 187],
        ['id' => 6, 'title' => 'Un lugar tranquilo', 'artist' => 'Mapa de Sal', 'duration' => 262],
        ['id' => 7, 'title' => 'Líneas del camino', 'artist' => 'Los Días Lentos', 'duration' => 231],
        ['id' => 8, 'title' => 'Antes del amanecer', 'artist' => 'Nube de Papel', 'duration' => 205],
        ['id' => 9, 'title' => 'Las cosas pequeñas', 'artist' => 'Casa de Niebla', 'duration' => 241],
        ['id' => 10, 'title' => 'Rumbo al norte', 'artist' => 'Casa de Niebla', 'duration' => 216],
    ],
    'playlists' => [
        ['id' => 'mezcla-diaria', 'title' => 'Mezcla diaria', 'description' => 'Una selección para acompañar tu día.', 'tracks' => [1, 2, 5, 7, 9]],
        ['id' => 'horas-lentas', 'title' => 'Horas lentas', 'description' => 'Canciones para bajar el ritmo.', 'tracks' => [3, 6, 8, 4]],
        ['id' => 'camino-abierto', 'title' => 'Camino abierto', 'description' => 'Una ruta para escuchar sin prisa.', 'tracks' => [7, 10, 2, 1, 5]],
        ['id' => 'luz-de-noche', 'title' => 'Luz de noche', 'description' => 'Sonidos para cerrar el día.', 'tracks' => [8, 4, 9, 6]],
    ],
];
