@props(['playlist', 'tracks' => []])
@php($count = count(data_get($playlist, 'tracks', [])))
<a href="{{ route('playlists.show', data_get($playlist, 'id')) }}" class="group block rounded-md bg-surface-raised p-4 transition duration-150 hover:bg-surface-high hover:shadow-raise">
    <div class="mb-4 flex aspect-square items-center justify-center rounded-md bg-surface-high text-ink-muted group-hover:bg-surface-base" aria-hidden="true"><x-icon name="library" class="h-12 w-12" /></div>
    <h3 class="text-xl font-bold leading-tight text-ink">{{ data_get($playlist, 'title') }}</h3>
    <p class="mt-1 line-clamp-2 text-sm text-ink-muted">{{ data_get($playlist, 'description') }}</p>
    <p class="mt-2 font-mono text-xs text-ink-muted">{{ $count }} canciones</p>
</a>
