@extends('layouts.app')
@section('title', data_get($playlist, 'title'))
@section('content')
<a href="{{ route('home') }}#playlists" class="inline-flex items-center gap-2 rounded-pill text-sm font-bold text-ink-muted hover:text-ink">← Volver a tus playlists</a>
<section class="mt-6 flex flex-col gap-6 rounded-lg bg-surface-raised p-6 sm:flex-row sm:items-end sm:p-8" aria-labelledby="playlist-title">
    <div class="flex aspect-square w-full max-w-56 shrink-0 items-center justify-center rounded-md bg-surface-high text-ink-muted" aria-hidden="true"><x-icon name="library" class="h-16 w-16" /></div>
    <div><p class="mb-2 text-xs font-bold uppercase tracking-wider text-ink-muted">Playlist</p><h1 id="playlist-title" class="text-4xl font-extrabold tracking-tight sm:text-5xl">{{ data_get($playlist, 'title') }}</h1><p class="mt-3 max-w-xl text-ink-muted">{{ data_get($playlist, 'description') }}</p><p class="mt-3 font-mono text-xs text-ink-muted">{{ count($playlistTracks) }} canciones</p>@if(count($playlistTracks))<button type="button" data-play-playlist="{{ $playlist['id'] }}" class="mt-6 inline-flex items-center gap-2 rounded-pill bg-accent px-6 py-3 text-sm font-bold text-on-accent hover:bg-accent-hover"><x-icon name="play" /> Reproducir playlist</button>@endif</div>
</section>
<section class="mt-8" aria-labelledby="tracklist-title"><div class="mb-4 flex items-center justify-between"><h2 id="tracklist-title" class="text-2xl font-extrabold tracking-tight">Canciones</h2><span class="font-mono text-xs text-ink-muted">Duración</span></div><div class="rounded-lg bg-surface-raised p-4">@forelse($playlistTracks as $track)<x-song-row :track="$track" :number="$loop->iteration" />@empty<p class="p-4 text-sm text-ink-muted">Esta playlist aún no tiene canciones.</p>@endforelse</div></section>
@endsection
