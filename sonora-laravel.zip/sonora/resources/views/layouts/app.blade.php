<!DOCTYPE html>
<html lang="es" data-theme="dark">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    
    <title>@yield('title', 'Tu música') · Sonora</title>
    @vite(['resources/css/app.css', 'resources/js/app.js'])
</head>
<body class="min-h-screen bg-surface-base font-sans text-ink antialiased">
@php($firstTrack = collect($tracks)->first())
<div class="min-h-screen pb-48 md:pb-28">
    <a href="#contenido" class="sr-only z-50 rounded-md bg-surface-high px-4 py-2 text-ink focus:not-sr-only focus:fixed focus:left-4 focus:top-4">Saltar al contenido</a>
    <aside class="fixed inset-y-0 left-0 z-20 hidden w-60 flex-col border-r border-line bg-surface-raised px-6 pb-32 pt-8 md:flex" aria-label="Navegación principal">
        <a href="{{ route('home') }}" class="mb-12 flex items-center gap-3 rounded-md text-xl font-extrabold tracking-tight"><x-logo class="h-8 w-8" /><span>Sonora</span></a>
        <nav class="space-y-2" aria-label="Secciones">
            <a href="{{ route('home') }}" @if(request()->routeIs('home')) aria-current="page" @endif class="flex items-center gap-3 rounded-md px-3 py-3 text-sm font-bold {{ request()->routeIs('home') ? 'bg-surface-high text-ink' : 'text-ink-muted hover:bg-surface-high hover:text-ink' }}"><x-icon name="home" /> Inicio</a>
            <a href="{{ route('home') }}#playlists" class="flex items-center gap-3 rounded-md px-3 py-3 text-sm font-bold text-ink-muted hover:bg-surface-high hover:text-ink"><x-icon name="library" /> Tu biblioteca</a>
            <a href="{{ route('player') }}" @if(request()->routeIs('player')) aria-current="page" @endif class="flex items-center gap-3 rounded-md px-3 py-3 text-sm font-bold {{ request()->routeIs('player') ? 'bg-surface-high text-ink' : 'text-ink-muted hover:bg-surface-high hover:text-ink' }}"><x-icon name="volume" /> Reproductor</a>
        </nav>
        <div class="mt-12 border-t border-line pt-6"><p class="mb-4 text-xs font-bold uppercase tracking-wider text-ink-muted">Tus playlists</p><div class="space-y-3">@foreach($playlists as $item)<a href="{{ route('playlists.show', data_get($item, 'id')) }}" class="block truncate rounded-sm text-sm text-ink-muted hover:text-ink">{{ data_get($item, 'title') }}</a>@endforeach</div></div>
        <p class="mt-auto text-xs text-ink-muted">Tu espacio para escuchar.</p>
    </aside>
    <div class="md:ml-60">
        <header class="flex items-center justify-between gap-4 border-b border-line px-4 py-4 sm:px-8">
            <a href="{{ route('home') }}" class="flex items-center gap-2 text-lg font-extrabold md:hidden"><x-logo class="h-7 w-7" />Sonora</a>
            <p class="hidden text-sm font-medium text-ink-muted md:block">Tu música, a tu ritmo</p>
            <div class="flex items-center gap-2"><a href="{{ route('player') }}" class="rounded-pill px-4 py-2 text-sm font-bold text-ink-muted hover:bg-surface-high hover:text-ink">En reproducción</a><button type="button" id="theme-toggle" class="rounded-pill border-2 border-line-strong px-4 py-2 text-sm font-bold text-ink hover:bg-surface-high" aria-label="Cambiar tema">Tema</button></div>
        </header>
        <main id="contenido" class="mx-auto max-w-7xl px-4 py-8 sm:px-8 lg:px-12">@yield('content')</main>
    </div>
</div>
<nav class="fixed bottom-24 left-0 right-0 z-20 flex justify-around border-t border-line bg-surface-raised px-2 py-2 md:hidden" aria-label="Navegación móvil">
    <a href="{{ route('home') }}" class="flex flex-col items-center gap-1 rounded-md px-4 py-1 text-xs text-ink-muted"><x-icon name="home" />Inicio</a>
    <a href="{{ route('home') }}#playlists" class="flex flex-col items-center gap-1 rounded-md px-4 py-1 text-xs text-ink-muted"><x-icon name="library" />Biblioteca</a>
    <a href="{{ route('player') }}" class="flex flex-col items-center gap-1 rounded-md px-4 py-1 text-xs text-ink-muted"><x-icon name="volume" />Reproductor</a>
</nav>
<footer class="fixed inset-x-0 bottom-0 z-30 flex h-24 items-center gap-2 border-t border-line bg-surface-raised px-4 sm:gap-6 sm:px-8" aria-label="Controles de reproducción">
    <div class="flex min-w-0 flex-1 items-center gap-3 sm:max-w-64">
        <div class="hidden h-14 w-14 shrink-0 items-center justify-center rounded-md bg-surface-high text-ink-muted sm:flex"><x-icon name="volume" /></div>
        <div class="min-w-0"><p id="player-title" class="truncate text-sm font-bold">{{ data_get($firstTrack, 'title', 'Elige una canción') }}</p><p id="player-artist" class="truncate text-xs text-ink-muted">{{ data_get($firstTrack, 'artist', 'Sonora') }}</p></div>
    </div>
    <div class="flex min-w-0 flex-1 flex-col items-center gap-1 sm:max-w-xl sm:flex-[2]">
        <div class="flex items-center justify-center gap-1 sm:gap-3">
            <button id="player-shuffle" type="button" class="hidden h-9 w-9 items-center justify-center rounded-pill text-ink-muted hover:bg-surface-high hover:text-ink sm:inline-flex" aria-label="Activar reproducción aleatoria" aria-pressed="false"><x-icon name="shuffle" /></button>
            <button id="player-prev" type="button" class="inline-flex h-9 w-9 items-center justify-center rounded-pill text-ink hover:bg-surface-high" aria-label="Canción anterior"><x-icon name="skip-prev" /></button>
            <button id="player-toggle" type="button" class="inline-flex h-10 w-10 items-center justify-center rounded-pill bg-ink text-surface-base hover:opacity-80" aria-label="Reproducir" aria-pressed="false"><span data-icon-play><x-icon name="play" /></span><span data-icon-pause hidden><x-icon name="pause" /></span></button>
            <button id="player-next" type="button" class="inline-flex h-9 w-9 items-center justify-center rounded-pill text-ink hover:bg-surface-high" aria-label="Siguiente canción"><x-icon name="skip-next" /></button>
        </div>
        <div class="hidden w-full items-center gap-3 sm:flex"><span id="player-current" class="w-10 text-right font-mono text-xs text-ink-muted">00:00</span><input id="player-progress" type="range" min="0" max="{{ data_get($firstTrack, 'duration', 0) }}" value="0" class="w-full accent-ink" aria-label="Posición de reproducción"><span id="player-duration" class="w-10 font-mono text-xs text-ink-muted">00:00</span></div>
    </div>
    <a href="{{ route('player') }}" class="hidden flex-1 justify-end text-sm font-bold text-ink-muted hover:text-ink lg:flex">Abrir reproductor</a>
</footer>
<script id="sonora-data" type="application/json">@json(['tracks' => array_values($tracks), 'playlists' => array_values($playlists)])</script>
</body>
</html>

