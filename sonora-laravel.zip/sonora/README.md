# Sonora

Aplicación de música de demostración construida con Laravel, Blade y Tailwind CSS. Incluye inicio, cuatro playlists, una pantalla de reproducción y diez canciones ficticias. La reproducción se simula con un temporizador: no incluye archivos de audio ni emite sonido.

## Requisitos

- PHP 8.3 o posterior y Composer.
- Node.js y npm (Node 20.19 o posterior, o 22.12 o posterior).
- Una terminal abierta en la carpeta `sonora`.

En Windows, si usas Laravel Herd, comprueba que PHP y Composer estén disponibles en la terminal con `php -v` y `composer -V`.

## Preparación y ejecución

Desde PowerShell, dentro de esta carpeta:

```powershell
composer install
Copy-Item .env.example .env
php artisan key:generate
npm ci
npm run build
php artisan serve
```

Abre la dirección que muestre el último comando (normalmente http://127.0.0.1:8000). Para trabajar en los estilos con actualización automática, ejecuta `npm run dev` en otra terminal. La aplicación usa datos de ejemplo de `config/sonora.php` y sesiones en archivos, por lo que no requiere configurar una base de datos ni ejecutar migraciones para estas pantallas.

## Uso

- En Inicio puedes abrir una de las cuatro playlists o elegir una canción.
- En una playlist, «Reproducir playlist» inicia su selección; también puedes seleccionar canciones individualmente.
- El reproductor permite pausar, cambiar de pista, activar el orden aleatorio y mover la posición con el ratón o el teclado. Su estado y el tema se guardan localmente en el navegador.
- La versión móvil adapta la navegación y el reproductor al espacio disponible.

## Organización y decisiones

- `resources/views`: pantallas Blade, diseño compartido y componentes reutilizables de icono, marca, tarjeta y fila de canción.
- `resources/css/app.css`: tokens semánticos del sistema, Tailwind y estilos comunes de accesibilidad.
- `resources/js/app.js`: estado y controles de la reproducción simulada.
- `config/sonora.php`: catálogo ficticio de canciones y playlists. Para una siguiente fase se podría trasladar a modelos, migraciones y una base de datos.
- `public/assets`: iconos y logotipos proporcionados. No se proporcionaron portadas; se usan marcadores lisos como indica el sistema.
- `docs/sistema-de-diseno`: copia del material de referencia recibido.

El diseño utiliza Manrope y JetBrains Mono desde Google Fonts, con fuentes de respaldo si no hay conexión. El contenido es una demostración y los nombres son inventados. Las capturas de pantalla solicitadas por el brief deben generarse después de ejecutar el proyecto en el navegador.
